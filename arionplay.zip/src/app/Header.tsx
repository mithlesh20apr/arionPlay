"use client";
import React, { useEffect, useState } from 'react';

const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 w-full bg-gray-900 text-white flex justify-between items-center z-50 shadow-md min-h-[100px] transition-all duration-300 px-[60px] ${scrolled ? 'backdrop-blur-md bg-opacity-80 translate-y-2 scale-95' : ''}`}
      style={{
        boxShadow: scrolled ? '0 4px 24px 0 rgba(0,0,0,0.25)' : undefined
      }}
    >
      <a href="/" className="mr-4 hover:underline">
        <img src="images/logo.svg" alt="Logo" style={{ width: 220 }} />
      </a>
      <nav className='navbar'>
        <a href="/register" className="registrion">Registraion</a>
        <a href="/login" className="login">Login</a>
      </nav>
    </header>
  );
};

export default Header;
