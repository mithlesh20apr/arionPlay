import React from 'react';

const Footer: React.FC = () => (
  <footer className="w-full footer-section text-white py-4 px-8 text-center">
     <section>
        <div className='w-full flex justify-center items-center footer-upper'>
          <p className="">
            We greatly appreciate your feedback! The dedicated ARIONPLAY team is available around the clock to asist you.
            Don't hesitate to contact us, and we assure you a prompt response.
             </p>
            <p>For any questions or queries email us at <a href='mailto:csr@nemo-ig.com'>csr@nemo-ig.com</a></p>
            <p>For support, please contact +639613970012 or +63961351865.</p>
         </div>
          <footer className=" text-white py-4" style={{ borderTop: "4px solid rgb(221, 99, 26)" }}>
            <div className="mx-auto ">
              <div className="flex flex-col md:flex-row justify-between items-center">
                <div className="mb-8 md:mb-0 w-full">
                <ul>
                    <li style={{  float: "left",borderRight: "1px solid #ccc",paddingRight: "20px",marginRight: "20px"}}> 
                        <img src="images/logo.svg" alt="Logo" style={{  }} />
                    </li>
                    <li>
                        <img src="images/footer-logo/footer-gaming-logo-DxGzLVzE.svg"/>
                    </li>
                </ul>
                  
                </div>
                
              </div>
              <div className="border-t border-gray-700 mt-4 pt-4 text-center" style={{borderTop: "1px solid #3a3a3a"}}>
                <div className="w-full space-x-6 footer-anchor">
                  <a href="#" className="hover:text-gray-300 transition-colors">
                    Terms & Conditions
                  </a>
                  <a href="#" className="hover:text-gray-300 transition-colors">
                    Services
                  </a>
                  <a href="#" className="hover:text-gray-300 transition-colors">
                    Locations
                  </a>
                  <a href="#" className="hover:text-gray-300 transition-colors">
                    Play Rules
                  </a>
                  <a href="#" className="hover:text-gray-300 transition-colors">
                    Responsible Gaming
                  </a>
                  <a href="#" className="hover:text-gray-300 transition-colors">
                    Privacy Policy
                  </a>
                  <a href="#" className="hover:text-gray-300 transition-colors">
                    About us
                  </a>
                  <a href="#" className="hover:text-gray-300 transition-colors">
                    Contact Us
                  </a>
                  <a href="#" className="hover:text-gray-300 transition-colors">
                    FAQs & Help
                  </a>
                  
                  <p className="text-gray-400">&copy; 2025. All rights reserved.</p>
                </div>
                
              </div>
            </div>
          </footer>
        </section>
  </footer>
);

export default Footer;
