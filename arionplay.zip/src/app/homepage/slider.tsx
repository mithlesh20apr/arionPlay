"use client";

import React, { useState, useRef } from "react";

const images = [
	"images/slider/jeepney_banner3.png",
    "images/slider/jeepney_banner4.png",
    "images/slider/jeepney_banner2.jpg",
    "images/slider/jeepney_banner1.png",
];

export default function Slider() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const touchStartX = useRef(0);
  const touchEndX = useRef(0);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState(0);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };
  const handleNext = () => {
    setCurrentIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    setIsDragging(true);
    touchStartX.current = e.touches[0].clientX;
    setDragOffset(0);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const offset = e.touches[0].clientX - touchStartX.current;
    setDragOffset(offset);
    touchEndX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    const distance = touchStartX.current - touchEndX.current;
    if (distance > 50) {
      handleNext(); // swipe left
    } else if (distance < -50) {
      handlePrev(); // swipe right
    }
    setDragOffset(0);
  };

  return (
    <div className="w-full relative h-[265px]">
      <div className="swiper-container relative overflow-hidden multiple-slider">
        <div
          className="swiper-wrapper flex transition-transform duration-300 ease-in-out"
          style={{
            transform: `translateX(-${currentIndex * 30}%)`, // 50% for two slides per view
          }}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          {images.map((image, index) => (
            <div
              key={index}
              className="swiper-slide flex-shrink-0 w-1/2 h-[400px] relative" // w-1/2 for two per view
              style={{
                transform: `translateX(${dragOffset}px)`,
                marginRight:  '10px', // Adjust margin for even/odd slides
                transition: isDragging ? 'none' : 'transform 0.3s ease-in-out',
              }}
            >
              <img
                src={image}
                alt={`Slide ${index + 1}`}
                className="h-[265px] w-full rounded-[5px] mr-[10px] object-cover"
              />
            </div>
          ))}
        </div>
      </div>
      <button
        className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-orange-500 p-2 rounded-full shadow-md hover:bg-gray-200 transition"
        onClick={handlePrev}
      >
        &#8592;
      </button>
      <button
        className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-orange-500 p-2 rounded-full shadow-md hover:bg-gray-200 transition"
        onClick={handleNext}
      >
        &#8594;
      </button>
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {Array.from({ length: Math.ceil(images.length) }).map((_, index) => (
          <span
            key={index}
            className={`w-3 h-3 rounded-full cursor-pointer ${currentIndex === index ? 'bg-orange-500' : 'bg-gray-300'}`}
            onClick={() => setCurrentIndex(index)}
          ></span>
        ))}
      </div>
    </div>
  );
}