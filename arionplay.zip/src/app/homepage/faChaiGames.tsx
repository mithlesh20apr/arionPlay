"use client"

import Image from "next/image"

const cards = [
  {
    image: "/images/fa-chiai/21003_200x200_en.png",
    alt: "Monkey King Fishing",
    title: "Monkey King Fishing",
    titleClass: "group-hover:text-green-600",
    imgClass: "group-hover:hue-rotate-15",
  },
  {
    image: "/images/fa-chiai/21009_200x200_en.png",
    alt: "Gods Grant Fortune",
    title: "Gods Grant Fortune",
    titleClass: "group-hover:text-blue-600",
    imgClass: "group-hover:hue-rotate-30",
  },
  {
    image: "/images/fa-chiai/22040_200x200_en.png",
    alt: "Sugar Bang Bang",
    title: "Sugar Bang Bang",
    titleClass: "group-hover:text-red-600",
    imgClass: "group-hover:hue-rotate-45",
  },
  {
    image: "/images/fa-chiai/22041_200x200_en.png",
    alt: "Lucky Fortunes",
    title: "Lucky Fortunes",
    titleClass: "group-hover:text-red-600",
    imgClass: "group-hover:hue-rotate-45",
  },
   {
    image: "/images/fa-chiai/22043_200x200_en.png",
    alt: "Chinese New Year2",
    title: "Chinese New Year2",
    titleClass: "group-hover:text-red-600",
    imgClass: "group-hover:hue-rotate-45",
  }
];

export default function FaChaiGames() {
  return (
    <div className="flex flex-col items-center justify-center w-full">
    
      <div className="w-full bg-black p-4">
          <h2 className="text-2xl w-full font-semibold text-gray-800 heading_new heading_inner">
      <svg  xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" className="size-6 img-icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="M16.712 4.33a9.027 9.027 0 0 1 1.652 1.306c.51.51.944 1.064 1.306 1.652M16.712 4.33l-3.448 4.138m3.448-4.138a9.014 9.014 0 0 0-9.424 0M19.67 7.288l-4.138 3.448m4.138-3.448a9.014 9.014 0 0 1 0 9.424m-4.138-5.976a3.736 3.736 0 0 0-.88-1.388 3.737 3.737 0 0 0-1.388-.88m2.268 2.268a3.765 3.765 0 0 1 0 2.528m-2.268-4.796a3.765 3.765 0 0 0-2.528 0m4.796 4.796c-.181.506-.475.982-.88 1.388a3.736 3.736 0 0 1-1.388.88m2.268-2.268 4.138 3.448m0 0a9.027 9.027 0 0 1-1.306 1.652c-.51.51-1.064.944-1.652 1.306m0 0-3.448-4.138m3.448 4.138a9.014 9.014 0 0 1-9.424 0m5.976-4.138a3.765 3.765 0 0 1-2.528 0m0 0a3.736 3.736 0 0 1-1.388-.88 3.737 3.737 0 0 1-.88-1.388m2.268 2.268L7.288 19.67m0 0a9.024 9.024 0 0 1-1.652-1.306 9.027 9.027 0 0 1-1.306-1.652m0 0 4.138-3.448M4.33 16.712a9.014 9.014 0 0 1 0-9.424m4.138 5.976a3.765 3.765 0 0 1 0-2.528m0 0c.181-.506.475-.982.88-1.388a3.736 3.736 0 0 1 1.388-.88m-2.268 2.268L4.33 7.288m6.406 1.18L7.288 4.33m0 0a9.024 9.024 0 0 0-1.652 1.306A9.025 9.025 0 0 0 4.33 7.288" />
</svg> Fa Chai Games
       
      </h2>
        <div className="max-w-7xl mx-auto space-y-12">
          <section className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
              {cards.map((card, idx) => (
                <div
                  key={idx}
                  className="overflow-hidden transition-opacity duration-700 opacity-0 animate-fade-in cursor-pointer group border-color-tab"
                  style={{ animationDelay: `${idx * 150}ms`, animationFillMode: "forwards" }}
                >
                  <Image
                    src={card.image}
                    alt={card.alt}
                    width={300}
                    height={200}
                    className={`w-full h-48 object-cover rounded-[5px] ${card.imgClass}`}
                  />
                  <h2 className="heading_name">
                    <span className={`text-lg transition-colors duration-300 ${card.titleClass}`}>
                      {card.title}
                    </span>
                  </h2>
                </div>
              ))}
              <a href="" className="w-full h-60 bg-gray-200 rounded-[5px] flex items-center justify-center view_all_button">
                <span className="text-gray-500">View All <svg  style={{ float: "right",marginLeft:"9px" }} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="size-6">
                <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 8.25 21 12m0 0-3.75 3.75M21 12H3" />
                </svg>
              </span>
                </a>
            </div>
          </section>
        </div>
      </div>
      <style jsx global>{`
        @keyframes fade-in {
          to {
            opacity: 1;
          }
        }
        .animate-fade-in {
          animation: fade-in 0.7s ease forwards;
        }
      `}</style>
    </div>
  );
}