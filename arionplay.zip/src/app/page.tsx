"use client";

import React, { useState } from "react";
import Slider from "./homepage/slider";
import NewGames from "./homepage/newGames";
import JilliGames from "./homepage/jilliGames";
import FaChaiGames from "./homepage/faChaiGames";
import PragmaticGames from "./homepage/pragmaticGames";
import Jdb from "./homepage/jdb";

// Slider component to display images with navigation buttons
export default function Home() {
	return (
		<main className="w-full   flex flex-col items-center justify-center py-5 mt-[90px] px-[60px]">
	<Slider />
	<NewGames />
	<JilliGames />
	<FaChaiGames />
  <PragmaticGames/>
  <Jdb/>
		</main>
	);
}
